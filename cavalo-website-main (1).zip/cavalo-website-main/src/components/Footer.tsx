import logo from "@/assets/logo.png";

const Footer = () => {
  return (
    <footer className="bg-charcoal border-t border-cream/10 py-12">
      <div className="container-custom">
        <div className="flex flex-col md:flex-row items-center justify-between gap-6">
          {/* Logo */}
          <div className="flex items-center gap-4">
            <img src={logo} alt="Cavalo Logo" className="h-12 w-auto" />
          </div>

          {/* Links */}
          <nav className="flex flex-wrap justify-center gap-6">
            <a href="#home" className="font-body text-sm text-cream/60 hover:text-gold-light transition-colors">
              Home
            </a>
            <a href="#about" className="font-body text-sm text-cream/60 hover:text-gold-light transition-colors">
              About
            </a>
            <a href="#services" className="font-body text-sm text-cream/60 hover:text-gold-light transition-colors">
              Services
            </a>
            <a href="#projects" className="font-body text-sm text-cream/60 hover:text-gold-light transition-colors">
              Projects
            </a>
            <a href="#contact" className="font-body text-sm text-cream/60 hover:text-gold-light transition-colors">
              Contact
            </a>
          </nav>

          {/* Copyright */}
          <p className="font-body text-sm text-cream/40">
            © {new Date().getFullYear()} Cavalo. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
