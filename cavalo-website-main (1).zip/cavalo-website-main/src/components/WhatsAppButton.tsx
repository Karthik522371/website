const WhatsAppButton = () => {
  const phoneNumber = "919916889014";
  const message = "Hello! I'm interested in your interior design services.";
  const whatsappUrl = `https://wa.me/${phoneNumber}?text=${encodeURIComponent(message)}`;

  return (
    <a
      href={whatsappUrl}
      target="_blank"
      rel="noopener noreferrer"
      className="fixed bottom-6 right-6 z-50 flex items-center gap-2 px-4 py-2.5 bg-[#25D366] rounded-full shadow-lg hover:shadow-xl hover:bg-[#20BD5A] transition-all duration-300"
      aria-label="Chat on WhatsApp"
    >
      <svg
        viewBox="0 0 32 32"
        className="w-5 h-5 fill-white"
        xmlns="http://www.w3.org/2000/svg"
      >
        <path d="M16.002 0C7.165 0 0 7.163 0 16c0 2.826.736 5.584 2.134 8.012L0 32l8.188-2.088A15.93 15.93 0 0016.002 32C24.837 32 32 24.837 32 16S24.837 0 16.002 0zm0 29.09a13.06 13.06 0 01-6.65-1.816l-.477-.283-4.948 1.263 1.324-4.832-.31-.495A13.014 13.014 0 012.91 16c0-7.216 5.874-13.09 13.092-13.09S29.09 8.784 29.09 16s-5.872 13.09-13.088 13.09zm7.173-9.806c-.393-.197-2.327-1.148-2.688-1.279-.36-.131-.623-.197-.885.197-.262.394-1.017 1.279-1.247 1.541-.23.263-.46.296-.853.099-.394-.197-1.662-.612-3.166-1.954-1.17-1.044-1.96-2.333-2.19-2.727-.23-.394-.025-.607.173-.803.177-.177.394-.46.59-.689.197-.23.263-.394.394-.656.131-.263.066-.493-.033-.69-.099-.197-.885-2.134-1.213-2.921-.32-.767-.644-.663-.885-.676-.23-.011-.493-.013-.755-.013-.263 0-.689.099-1.05.493-.36.394-1.377 1.345-1.377 3.28s1.41 3.806 1.607 4.069c.197.262 2.777 4.24 6.728 5.946.94.406 1.674.648 2.246.83.943.3 1.802.257 2.48.156.757-.113 2.328-.952 2.656-1.872.328-.919.328-1.706.23-1.872-.099-.164-.361-.262-.755-.459z"/>
      </svg>
      <span className="text-white text-sm font-medium">Chat with us</span>
    </a>
  );
};

export default WhatsAppButton;
