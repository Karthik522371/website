import { Star, Quote } from "lucide-react";
import { useState, useEffect } from "react";

const reviews = [
  {
    name: "Priya Sharma",
    location: "Bangalore",
    rating: 5,
    review: "Cavalo transformed our 3BHK into a stunning modern home. Their attention to detail and understanding of our vision was exceptional. The modular kitchen they designed is absolutely beautiful!",
    project: "Residential Interior",
  },
  {
    name: "Rajesh Kumar",
    location: "Mysore",
    rating: 5,
    review: "Outstanding work on our restaurant interior. The team delivered beyond expectations, creating a warm and inviting atmosphere that our customers love. Highly professional and timely execution.",
    project: "Commercial Interior",
  },
  {
    name: "Anitha Reddy",
    location: "Malur",
    rating: 5,
    review: "From the initial consultation to the final handover, Cavalo made the entire process seamless. Our villa design exceeded all expectations with perfect Vastu compliance.",
    project: "Civil & Architectural",
  },
  {
    name: "Mohammed Farhan",
    location: "Kolar",
    rating: 5,
    review: "The 3D visualization helped us see exactly what our office would look like before construction. The turnkey execution was flawless. Best investment we made for our business!",
    project: "Consulting & Contracting",
  },
  {
    name: "Lakshmi Devi",
    location: "Bangalore",
    rating: 5,
    review: "Cavalo designed our entire home with such elegance. The false ceiling work and lighting design created the perfect ambiance. Their team is creative, responsive, and truly passionate.",
    project: "Residential Interior",
  },
];

const ReviewsSection = () => {
  const [activeIndex, setActiveIndex] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setActiveIndex((prev) => (prev + 1) % reviews.length);
    }, 5000);
    return () => clearInterval(interval);
  }, []);

  return (
    <section className="section-padding bg-muted/30">
      <div className="container-custom">
        {/* Section Header */}
        <div className="text-center mb-12 md:mb-16">
          <p className="font-body text-primary text-sm uppercase tracking-[0.25em] mb-3">
            Testimonials
          </p>
          <h2 className="font-heading text-3xl md:text-4xl lg:text-5xl text-foreground mb-4">
            What Our <span className="text-gradient-gold italic">Clients Say</span>
          </h2>
          <div className="w-20 h-0.5 bg-gradient-gold mx-auto mb-6" />
          <p className="font-body text-muted-foreground max-w-2xl mx-auto">
            Don't just take our word for it — hear from our satisfied clients about their experience with Cavalo.
          </p>
        </div>

        {/* Reviews Carousel */}
        <div className="relative max-w-4xl mx-auto">
          {/* Quote Icon */}
          <div className="absolute -top-4 left-1/2 -translate-x-1/2 z-10">
            <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center">
              <Quote className="w-8 h-8 text-primary" />
            </div>
          </div>

          {/* Main Review Card */}
          <div className="bg-card border border-border rounded-sm p-8 md:p-12 pt-14 md:pt-16 shadow-lg">
            <div className="text-center">
              {/* Stars */}
              <div className="flex justify-center gap-1 mb-6">
                {[...Array(reviews[activeIndex].rating)].map((_, i) => (
                  <Star
                    key={i}
                    className="w-5 h-5 fill-primary text-primary"
                  />
                ))}
              </div>

              {/* Review Text */}
              <p className="font-body text-foreground text-lg md:text-xl leading-relaxed mb-8 italic">
                "{reviews[activeIndex].review}"
              </p>

              {/* Reviewer Info */}
              <div className="space-y-2">
                <h4 className="font-heading text-xl text-foreground">
                  {reviews[activeIndex].name}
                </h4>
                <p className="font-body text-muted-foreground text-sm">
                  {reviews[activeIndex].location}
                </p>
                <span className="inline-block px-4 py-1 bg-primary/10 text-primary text-xs uppercase tracking-wider rounded-full">
                  {reviews[activeIndex].project}
                </span>
              </div>
            </div>
          </div>

          {/* Navigation Dots */}
          <div className="flex justify-center gap-3 mt-8">
            {reviews.map((_, index) => (
              <button
                key={index}
                onClick={() => setActiveIndex(index)}
                className={`w-3 h-3 rounded-full transition-all duration-300 ${
                  index === activeIndex
                    ? "bg-primary w-8"
                    : "bg-primary/30 hover:bg-primary/50"
                }`}
                aria-label={`Go to review ${index + 1}`}
              />
            ))}
          </div>
        </div>

      </div>
    </section>
  );
};

export default ReviewsSection;