import { Gem, Settings, Palette, Building2, CalendarCheck, ShieldCheck } from "lucide-react";

const usps = [
  {
    icon: Gem,
    title: "Luxury Within Reach",
    description: "Premium designs, smart material choices, and optimized planning — all crafted to fit your budget.",
  },
  {
    icon: Settings,
    title: "End-to-End Turnkey Execution",
    description: "From concept to final handover, we manage everything — design, materials, labour, vendors, and execution.",
  },
  {
    icon: Palette,
    title: "Customized Design Approach",
    description: "No templates or repetitive layouts. Every project is unique, personalized and built around your lifestyle.",
  },
  {
    icon: Building2,
    title: "Expert Architectural Solutions",
    description: "We design not just interiors, but structures, extensions, façades, and complete architectural layouts.",
  },
  {
    icon: CalendarCheck,
    title: "On-Time Delivery",
    description: "Clear costing, regular updates, and structured project timelines — ensuring a smooth experience.",
  },
  {
    icon: ShieldCheck,
    title: "Quality Without Compromise",
    description: "We work with trusted vendors, premium materials, skilled craftsmen, and strict quality checks.",
  },
];

const USPSection = () => {
  return (
    <section className="section-padding bg-secondary">
      <div className="container-custom">
        {/* Section Header */}
        <div className="text-center mb-16">
          <p className="font-body text-primary text-sm uppercase tracking-[0.25em] mb-3">
            Why Choose Us
          </p>
          <h2 className="font-heading text-3xl md:text-4xl lg:text-5xl text-foreground mb-4">
            What Makes Us <span className="text-gradient-gold italic">Unique</span>
          </h2>
          <div className="w-20 h-0.5 bg-gradient-gold mx-auto" />
        </div>

        {/* USP Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {usps.map((usp, index) => (
            <div
              key={usp.title}
              className="bg-background p-8 rounded-sm border border-border hover:border-primary/40 hover:shadow-elegant transition-all duration-300 group"
              style={{ animationDelay: `${index * 100}ms` }}
            >
              <div className="w-14 h-14 rounded-sm bg-gradient-gold flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                <usp.icon className="w-7 h-7 text-primary-foreground" />
              </div>
              <h3 className="font-heading text-xl text-foreground mb-3">
                {usp.title}
              </h3>
              <p className="font-body text-muted-foreground leading-relaxed">
                {usp.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default USPSection;
