import portfolio1 from "@/assets/portfolio-1.jpg";
import portfolio2 from "@/assets/portfolio-2.jpg";
import portfolio3 from "@/assets/portfolio-3.jpg";
import portfolio4 from "@/assets/portfolio-4.jpg";
import portfolio5 from "@/assets/portfolio-5.jpg";
import portfolio6 from "@/assets/portfolio-6.jpg";

const projects = [
  { image: portfolio1, category: "Modern Urban Homes", title: "Contemporary Living Space" },
  { image: portfolio2, category: "Office Workspaces", title: "Executive Conference Room" },
  { image: portfolio3, category: "Luxury Apartments", title: "Grand Living Hall" },
  { image: portfolio4, category: "Duplex & Villa Interiors", title: "Elegant Villa Design" },
  { image: portfolio5, category: "Duplex & Villa Interiors", title: "Classic Luxury Interior" },
  { image: portfolio6, category: "Renovation Projects", title: "Heritage Restoration" },
];

const ProjectsSection = () => {
  return (
    <section id="projects" className="section-padding bg-secondary">
      <div className="container-custom">
        {/* Section Header */}
        <div className="text-center mb-16">
          <p className="font-body text-primary text-sm uppercase tracking-[0.25em] mb-3">
            Our Portfolio
          </p>
          <h2 className="font-heading text-3xl md:text-4xl lg:text-5xl text-foreground mb-4">
            Designs Crafted With <span className="text-gradient-gold italic">Purpose</span>
          </h2>
          <div className="w-20 h-0.5 bg-gradient-gold mx-auto mb-6" />
          <p className="font-body text-muted-foreground max-w-2xl mx-auto">
            Every project at Cavalo is a reflection of collaboration, creativity, and craftsmanship. We take pride in delivering spaces that are not only beautiful but functional and long-lasting.
          </p>
        </div>

        {/* Projects Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {projects.map((project, index) => (
            <div
              key={index}
              className="group relative overflow-hidden rounded-sm cursor-pointer"
            >
              <div className="aspect-[4/3] overflow-hidden">
                <img
                  src={project.image}
                  alt={project.title}
                  className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                />
              </div>
              
              {/* Overlay */}
              <div className="absolute inset-0 bg-gradient-to-t from-charcoal/90 via-charcoal/30 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500 flex flex-col justify-end p-6">
                <p className="font-body text-gold-light text-xs uppercase tracking-wider mb-1 translate-y-4 group-hover:translate-y-0 transition-transform duration-300">
                  {project.category}
                </p>
                <h3 className="font-heading text-xl text-cream translate-y-4 group-hover:translate-y-0 transition-transform duration-300 delay-75">
                  {project.title}
                </h3>
              </div>

              {/* Border glow effect */}
              <div className="absolute inset-0 border-2 border-transparent group-hover:border-primary/40 transition-colors duration-500 rounded-sm pointer-events-none" />
            </div>
          ))}
        </div>

        {/* CTA */}
        <div className="text-center mt-12">
          <a
            href="#contact"
            className="inline-flex bg-gradient-gold text-primary-foreground px-8 py-3.5 rounded-sm font-body text-sm uppercase tracking-wider hover:opacity-90 transition-all shadow-gold"
          >
            Start Your Project
          </a>
        </div>
      </div>
    </section>
  );
};

export default ProjectsSection;
