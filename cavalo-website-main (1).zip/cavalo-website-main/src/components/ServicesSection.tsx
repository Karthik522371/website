import { ArrowRight, X } from "lucide-react";
import { useState, useRef, useEffect } from "react";
import residential from "@/assets/residential.png";
import commercial from "@/assets/commercial.png";
import civil from "@/assets/civil.png";
import consulting from "@/assets/consulting.png";

// Residential gallery images
import residential1 from "@/assets/residential-1.jpg";
import residential2 from "@/assets/residential-2.jpg";
import residential3 from "@/assets/residential-3.jpg";
import residential4 from "@/assets/residential-4.png";
import residential5 from "@/assets/residential-5.jpg";
import residential6 from "@/assets/residential-6.png";

// Commercial gallery images
import commercial1 from "@/assets/commercial-1.jpg";
import commercial2 from "@/assets/commercial-2.jpg";
import commercial6 from "@/assets/commercial-6.jpg";
import commercial7 from "@/assets/commercial-7.jpg";
import commercial8 from "@/assets/commercial-8.jpg";
import commercial9 from "@/assets/commercial-9.jpg";

// Civil gallery images
import civil1 from "@/assets/civil-1.jpg";
import civil2 from "@/assets/civil-2.jpg";
import civil3 from "@/assets/civil-3.jpg";
import civil4 from "@/assets/civil-4.jpg";
import civil5 from "@/assets/civil-5.jpg";
import civil6 from "@/assets/civil-6.jpg";

// Consulting gallery images
import consulting1 from "@/assets/consulting-1.jpg";
import consulting2 from "@/assets/consulting-2.jpg";
import consulting3 from "@/assets/consulting-3.jpg";
import consulting4 from "@/assets/consulting-4.jpg";
import consulting5 from "@/assets/consulting-5.jpg";
import consulting6 from "@/assets/consulting-6.jpg";

const galleries = {
  "Residential Interiors": [
    { image: residential1, title: "Modular Kitchen", description: "Sleek U-shaped modular kitchen with premium finishes" },
    { image: residential2, title: "Kitchen Storage", description: "Elegant kitchen with smart storage solutions" },
    { image: residential3, title: "Living & Dining", description: "Open concept living and dining space design" },
    { image: residential4, title: "Master Bedroom", description: "Luxurious bedroom with custom wall art" },
    { image: residential5, title: "Dining Space", description: "Contemporary dining area with statement chandelier" },
    { image: residential6, title: "Classic Bedroom", description: "Elegant classic bedroom with ornate details" },
  ],
  "Commercial Interiors": [
    { image: commercial1, title: "Executive Office", description: "Luxury corporate office with gold accents" },
    { image: commercial2, title: "Retail Showroom", description: "High-end boutique with elegant displays" },
    { image: commercial7, title: "Conference Room", description: "Premium boardroom with trophy displays" },
    { image: commercial8, title: "Executive Boardroom", description: "Sophisticated meeting space with wood paneling" },
    { image: commercial9, title: "Modern Boardroom", description: "Contemporary executive meeting room" },
    { image: commercial6, title: "Hotel Lobby", description: "Grand hospitality reception area" },
  ],
  "Civil & Architectural Design": [
    { image: civil1, title: "Villa Design", description: "Modern luxury villa exterior elevation" },
    { image: civil2, title: "Floor Planning", description: "Detailed 3D floor plan visualization" },
    { image: civil3, title: "Facade Design", description: "Contemporary building elevation" },
    { image: civil4, title: "Renovation", description: "Before & after home transformation" },
    { image: civil5, title: "Vastu Design", description: "Traditional modern fusion architecture" },
    { image: civil6, title: "Multi-Story", description: "Residential apartment building design" },
  ],
  "Consulting & Contracting": [
    { image: consulting1, title: "3D Visualization", description: "Photorealistic interior rendering" },
    { image: consulting2, title: "Material Selection", description: "Premium material samples board" },
    { image: consulting3, title: "Site Supervision", description: "Professional construction oversight" },
    { image: consulting4, title: "Vendor Management", description: "Collaborative project coordination" },
    { image: consulting5, title: "Turnkey Delivery", description: "Complete luxury home handover" },
    { image: consulting6, title: "Virtual Walkthrough", description: "Immersive 3D home experience" },
  ],
};

const services = [
  {
    image: residential,
    title: "Residential Interiors",
    items: [
      "Modular kitchens",
      "Living & dining spaces",
      "Bedrooms & wardrobes",
      "False ceiling & lighting",
      "Renovations & makeovers",
      "Interior Designs that suits your personality",
    ],
    hasGallery: true,
  },
  {
    image: commercial,
    title: "Commercial Interiors",
    items: [
      "Office spaces",
      "Retail stores & showrooms",
      "Restaurants & cafés",
      "Hospitality spaces",
      "Corporate interior planning",
    ],
    hasGallery: true,
  },
  {
    image: civil,
    title: "Civil & Architectural Design",
    items: [
      "New building design",
      "Renovations & extensions",
      "Floor plans & structural planning",
      "Elevation & façade design",
      "Vastu-based design layout",
    ],
    hasGallery: true,
  },
  {
    image: consulting,
    title: "Consulting & Contracting",
    items: [
      "3D visualization",
      "Material selection",
      "Site supervision",
      "Vendor management",
      "Turnkey project execution",
    ],
    hasGallery: true,
  },
];

const ServicesSection = () => {
  const [expandedService, setExpandedService] = useState<string | null>(null);
  const galleryRef = useRef<HTMLDivElement>(null);

  const handleLearnMore = (serviceTitle: string, hasGallery: boolean) => {
    if (hasGallery) {
      const newState = expandedService === serviceTitle ? null : serviceTitle;
      setExpandedService(newState);
    } else {
      document.getElementById("contact")?.scrollIntoView({ behavior: "smooth" });
    }
  };

  // Scroll to gallery when it opens
  useEffect(() => {
    if (expandedService && galleryRef.current) {
      setTimeout(() => {
        galleryRef.current?.scrollIntoView({ behavior: "smooth", block: "start" });
      }, 100);
    }
  }, [expandedService]);

  // Render gallery component
  const renderGallery = (serviceTitle: string) => {
    const galleryItems = galleries[serviceTitle as keyof typeof galleries];
    if (!galleryItems) return null;

    return (
      <div 
        ref={galleryRef}
        className="col-span-full overflow-hidden"
      >
        <div 
          className={`transition-all duration-500 ease-out ${
            expandedService === serviceTitle 
              ? "opacity-100 translate-y-0 max-h-[1000px]" 
              : "opacity-0 -translate-y-4 max-h-0"
          }`}
        >
          <div className="bg-card border border-primary/20 rounded-sm p-6 md:p-8 mt-4">
            <div className="flex items-center justify-between mb-6 md:mb-8">
              <div>
                <p className="font-body text-primary text-xs md:text-sm uppercase tracking-[0.25em] mb-2">
                  {serviceTitle}
                </p>
                <h4 className="font-heading text-xl md:text-2xl lg:text-3xl text-foreground">
                  Our <span className="text-gradient-gold italic">Designs</span>
                </h4>
              </div>
              <button
                onClick={() => setExpandedService(null)}
                className="p-2 md:p-3 hover:bg-muted rounded-full transition-colors border border-border"
              >
                <X size={20} className="text-muted-foreground" />
              </button>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-4 md:gap-6">
              {galleryItems.map((item, idx) => (
                <div
                  key={idx}
                  className="group/gallery relative overflow-hidden rounded-sm cursor-pointer transition-all duration-300"
                  style={{
                    opacity: expandedService === serviceTitle ? 1 : 0,
                    transform: expandedService === serviceTitle ? "translateY(0)" : "translateY(20px)",
                    transitionDelay: `${idx * 100}ms`,
                  }}
                >
                  <div className="aspect-[4/3] overflow-hidden">
                    <img
                      src={item.image}
                      alt={item.title}
                      className="w-full h-full object-cover transition-transform duration-500 group-hover/gallery:scale-110"
                    />
                  </div>
                  <div className="absolute inset-0 bg-gradient-to-t from-charcoal/90 via-charcoal/30 to-transparent" />
                  <div className="absolute bottom-0 left-0 right-0 p-3 md:p-4">
                    <p className="font-heading text-cream text-sm md:text-base lg:text-lg">{item.title}</p>
                    <p className="font-body text-cream/80 text-xs md:text-sm mt-1 line-clamp-2">{item.description}</p>
                  </div>
                </div>
              ))}
            </div>
            <div className="text-center mt-6 md:mt-8">
              <a
                href="#contact"
                className="inline-flex items-center gap-2 px-6 py-3 bg-primary text-primary-foreground font-body text-sm uppercase tracking-wide rounded-sm hover:bg-primary/90 transition-all"
              >
                Get a Quote <ArrowRight size={16} />
              </a>
            </div>
          </div>
        </div>
      </div>
    );
  };

  return (
    <section id="services" className="section-padding bg-background">
      <div className="container-custom">
        {/* Section Header */}
        <div className="text-center mb-16">
          <p className="font-body text-primary text-sm uppercase tracking-[0.25em] mb-3">
            Our Expertise
          </p>
          <h2 className="font-heading text-3xl md:text-4xl lg:text-5xl text-foreground mb-4">
            Services We <span className="text-gradient-gold italic">Offer</span>
          </h2>
          <div className="w-20 h-0.5 bg-gradient-gold mx-auto mb-6" />
          <p className="font-body text-muted-foreground max-w-2xl mx-auto">
            Comprehensive design and execution services tailored to bring your vision to life.
          </p>
        </div>

        {/* Services Grid */}
        <div className="grid md:grid-cols-2 gap-8">
          {services.map((service, index) => (
            <>
              <div key={service.title} className="space-y-4">
                <div
                  className="group relative overflow-hidden rounded-sm bg-card border border-border hover:border-primary/30 transition-all duration-500"
                >
                  {/* Image */}
                  <div className="relative h-64 overflow-hidden">
                    <img
                      src={service.image}
                      alt={service.title}
                      className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-charcoal/80 via-charcoal/20 to-transparent" />
                    <h3 className="absolute bottom-6 left-6 font-heading text-2xl text-cream">
                      {service.title}
                    </h3>
                  </div>

                  {/* Content */}
                  <div className="p-6">
                    <ul className="space-y-2">
                      {service.items.map((item) => (
                        <li key={item} className="flex items-center gap-3 font-body text-muted-foreground">
                          <span className="w-1.5 h-1.5 rounded-full bg-primary flex-shrink-0" />
                          {item}
                        </li>
                      ))}
                    </ul>
                    <button
                      onClick={() => handleLearnMore(service.title, service.hasGallery)}
                      className="inline-flex items-center gap-2 mt-6 text-primary font-body text-sm uppercase tracking-wide hover:gap-4 transition-all"
                    >
                      {service.hasGallery ? (expandedService === service.title ? "Close Gallery" : "View Designs") : "Learn More"} 
                      <ArrowRight size={16} className={`transition-transform duration-300 ${expandedService === service.title ? "rotate-90" : ""}`} />
                    </button>
                  </div>
                </div>
              </div>
              
              {/* Insert gallery right after each service card when expanded */}
              {service.hasGallery && expandedService === service.title && renderGallery(service.title)}
            </>
          ))}
        </div>
      </div>
    </section>
  );
};

export default ServicesSection;