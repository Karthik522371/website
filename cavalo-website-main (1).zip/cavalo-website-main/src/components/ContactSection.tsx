import { MapPin, Phone, Mail, Instagram, Globe } from "lucide-react";

const ContactSection = () => {
  return (
    <section id="contact" className="section-padding bg-charcoal text-cream">
      <div className="container-custom">
        {/* Section Header */}
        <div className="text-center mb-16">
          <p className="font-body text-gold-light text-sm uppercase tracking-[0.25em] mb-3">
            Get In Touch
          </p>
          <h2 className="font-heading text-3xl md:text-4xl lg:text-5xl text-cream mb-4">
            Let's Build Your <span className="text-gradient-gold italic">Dream Space</span>
          </h2>
          <div className="w-20 h-0.5 bg-gradient-gold mx-auto" />
        </div>

        <div className="grid lg:grid-cols-2 gap-12 lg:gap-16">
          {/* Contact Info */}
          <div className="space-y-8">
            <p className="font-body text-cream/80 text-lg leading-relaxed">
              Ready to transform your space? Whether it's a cozy home, a modern office, or a complete architectural project, we're here to bring your vision to life.
            </p>

            <div className="space-y-6">
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 rounded-sm bg-gradient-gold flex items-center justify-center flex-shrink-0">
                  <MapPin className="w-5 h-5 text-primary-foreground" />
                </div>
                <div>
                  <h4 className="font-heading text-lg text-cream mb-1">Visit Us</h4>
                  <p className="font-body text-cream/70">
                    No 236, 67th Cross, 5th Block<br />
                    Rajajinagar, Bengaluru – 560010
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <div className="w-12 h-12 rounded-sm bg-gradient-gold flex items-center justify-center flex-shrink-0">
                  <Phone className="w-5 h-5 text-primary-foreground" />
                </div>
                <div>
                  <h4 className="font-heading text-lg text-cream mb-1">Call Us</h4>
                  <a href="tel:+919916889014" className="font-body text-cream/70 hover:text-gold-light transition-colors">
                    +91 99168 89014
                  </a>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <div className="w-12 h-12 rounded-sm bg-gradient-gold flex items-center justify-center flex-shrink-0">
                  <Mail className="w-5 h-5 text-primary-foreground" />
                </div>
                <div>
                  <h4 className="font-heading text-lg text-cream mb-1">Email Us</h4>
                  <a href="mailto:dc@cavaloindia.com" className="font-body text-cream/70 hover:text-gold-light transition-colors">
                    dc@cavaloindia.com
                  </a>
                </div>
              </div>

              <div className="flex items-center gap-4 pt-4">
                <a
                  href="https://instagram.com/cavalo.designs"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-12 h-12 rounded-sm border border-cream/20 flex items-center justify-center hover:border-gold-light hover:bg-gold-light/10 transition-all"
                  aria-label="Instagram"
                >
                  <Instagram className="w-5 h-5 text-cream" />
                </a>
                <a
                  href="https://cavaloindia.com"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-12 h-12 rounded-sm border border-cream/20 flex items-center justify-center hover:border-gold-light hover:bg-gold-light/10 transition-all"
                  aria-label="Website"
                >
                  <Globe className="w-5 h-5 text-cream" />
                </a>
              </div>
            </div>
          </div>

          {/* Contact Form */}
          <form className="space-y-6">
            <div className="grid sm:grid-cols-2 gap-6">
              <div>
                <label htmlFor="name" className="block font-body text-sm text-cream/80 mb-2">
                  Your Name
                </label>
                <input
                  type="text"
                  id="name"
                  className="w-full bg-cream/5 border border-cream/20 rounded-sm px-4 py-3 font-body text-cream placeholder:text-cream/40 focus:outline-none focus:border-gold-light transition-colors"
                  placeholder="John Doe"
                />
              </div>
              <div>
                <label htmlFor="phone" className="block font-body text-sm text-cream/80 mb-2">
                  Phone Number
                </label>
                <input
                  type="tel"
                  id="phone"
                  className="w-full bg-cream/5 border border-cream/20 rounded-sm px-4 py-3 font-body text-cream placeholder:text-cream/40 focus:outline-none focus:border-gold-light transition-colors"
                  placeholder="+91 XXXXX XXXXX"
                />
              </div>
            </div>
            
            <div>
              <label htmlFor="email" className="block font-body text-sm text-cream/80 mb-2">
                Email Address
              </label>
              <input
                type="email"
                id="email"
                className="w-full bg-cream/5 border border-cream/20 rounded-sm px-4 py-3 font-body text-cream placeholder:text-cream/40 focus:outline-none focus:border-gold-light transition-colors"
                placeholder="john@example.com"
              />
            </div>

            <div>
              <label htmlFor="service" className="block font-body text-sm text-cream/80 mb-2">
                Service Interested In
              </label>
              <select
                id="service"
                className="w-full bg-cream/5 border border-cream/20 rounded-sm px-4 py-3 font-body text-cream focus:outline-none focus:border-gold-light transition-colors appearance-none cursor-pointer"
              >
                <option value="" className="bg-charcoal">Select a service</option>
                <option value="residential" className="bg-charcoal">Residential Interiors</option>
                <option value="commercial" className="bg-charcoal">Commercial Interiors</option>
                <option value="architectural" className="bg-charcoal">Civil & Architectural Design</option>
                <option value="consulting" className="bg-charcoal">Consulting & Contracting</option>
              </select>
            </div>

            <div>
              <label htmlFor="message" className="block font-body text-sm text-cream/80 mb-2">
                Your Message
              </label>
              <textarea
                id="message"
                rows={4}
                className="w-full bg-cream/5 border border-cream/20 rounded-sm px-4 py-3 font-body text-cream placeholder:text-cream/40 focus:outline-none focus:border-gold-light transition-colors resize-none"
                placeholder="Tell us about your project..."
              />
            </div>

            <button
              type="submit"
              className="w-full bg-gradient-gold text-primary-foreground py-4 rounded-sm font-body text-sm uppercase tracking-wider hover:opacity-90 transition-all shadow-gold"
            >
              Send Message
            </button>
          </form>
        </div>
      </div>
    </section>
  );
};

export default ContactSection;
