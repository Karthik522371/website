import { Award, Clock, Users, CheckCircle } from "lucide-react";

const features = [
  { icon: Award, label: "Premium Quality" },
  { icon: Clock, label: "On-Time Delivery" },
  { icon: Users, label: "Expert Team" },
  { icon: CheckCircle, label: "Turnkey Solutions" },
];

const AboutSection = () => {
  return (
    <section id="about" className="section-padding bg-background">
      <div className="container-custom">
        {/* Section Header */}
        <div className="text-center mb-16">
          <p className="font-body text-primary text-sm uppercase tracking-[0.25em] mb-3">
            Our Story
          </p>
          <h2 className="font-heading text-3xl md:text-4xl lg:text-5xl text-foreground mb-4">
            Where Vision Meets <span className="text-gradient-gold italic">Craftsmanship</span>
          </h2>
          <div className="w-20 h-0.5 bg-gradient-gold mx-auto" />
        </div>

        <div className="grid lg:grid-cols-2 gap-12 lg:gap-16 items-center">
          {/* Text Content */}
          <div className="space-y-6">
            <p className="font-body text-lg text-muted-foreground leading-relaxed">
              Cavalo was founded with a simple belief — <strong className="text-foreground">luxury shouldn't be out of reach</strong>. What began as a passion for thoughtful design has grown into a full-fledged interior and architectural design studio that blends creativity, functionality, and affordability.
            </p>
            <p className="font-body text-muted-foreground leading-relaxed">
              With years of hands-on experience in residential, commercial, and architectural projects, our team brings a deep understanding of lifestyle, space planning, and material excellence. At Cavalo, every design starts with a story — <em className="text-primary">your story</em>.
            </p>
            <p className="font-body text-muted-foreground leading-relaxed">
              We listen, understand, and translate your ideas into spaces that inspire, comfort, and elevate everyday living. From modern homes to smart workspaces, our goal is to create personalised, timeless spaces that reflect individuality, without compromising on quality or budget.
            </p>
            
            <div className="pt-6">
              <p className="font-heading text-xl md:text-2xl text-foreground italic">
                "Cavalo — Customized Luxury Interiors at an Affordable Budget."
              </p>
            </div>
          </div>

          {/* Features Grid */}
          <div className="grid grid-cols-2 gap-6">
            {features.map((feature, index) => (
              <div
                key={feature.label}
                className="bg-card p-6 md:p-8 rounded-sm border border-border hover:border-primary/30 hover:shadow-card transition-all duration-300 group"
                style={{ animationDelay: `${index * 100}ms` }}
              >
                <feature.icon className="w-10 h-10 text-primary mb-4 group-hover:scale-110 transition-transform" />
                <h3 className="font-heading text-lg text-foreground">{feature.label}</h3>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default AboutSection;
