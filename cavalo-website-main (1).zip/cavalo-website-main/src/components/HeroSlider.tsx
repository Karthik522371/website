import { useState, useEffect, useCallback } from "react";
import { ChevronLeft, ChevronRight } from "lucide-react";
import hero1 from "@/assets/hero-1.png";
import hero2 from "@/assets/hero-2.png";
import hero3 from "@/assets/hero-3.png";

const slides = [
  {
    image: hero1,
    title: "Customized Luxury Interiors",
    subtitle: "At an Affordable Budget",
  },
  {
    image: hero2,
    title: "Where Vision Meets",
    subtitle: "Craftsmanship",
  },
  {
    image: hero3,
    title: "Timeless Spaces",
    subtitle: "That Inspire",
  },
];

const HeroSlider = () => {
  const [currentSlide, setCurrentSlide] = useState(0);

  const nextSlide = useCallback(() => {
    setCurrentSlide((prev) => (prev + 1) % slides.length);
  }, []);

  const prevSlide = () => {
    setCurrentSlide((prev) => (prev - 1 + slides.length) % slides.length);
  };

  useEffect(() => {
    const timer = setInterval(nextSlide, 6000);
    return () => clearInterval(timer);
  }, [nextSlide]);

  return (
    <section id="home" className="relative h-screen w-full overflow-hidden">
      {/* Slides */}
      {slides.map((slide, index) => (
        <div
          key={index}
          className={`absolute inset-0 transition-opacity duration-1000 ${
            index === currentSlide ? "opacity-100" : "opacity-0"
          }`}
        >
          <img
            src={slide.image}
            alt={slide.title}
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-charcoal/40 via-charcoal/30 to-charcoal/60" />
        </div>
      ))}

      {/* Content */}
      <div className="absolute inset-0 flex items-center justify-center">
        <div className="container-custom text-center">
          <div className="max-w-4xl mx-auto">
            <p className="font-body text-gold-light text-sm md:text-base uppercase tracking-[0.3em] mb-4 animate-fade-in">
              Cavalo Interiors & Architectural Designs
            </p>
            <h1
              key={currentSlide}
              className="font-heading text-4xl md:text-6xl lg:text-7xl text-cream mb-4 animate-fade-in-up"
            >
              {slides[currentSlide].title}
            </h1>
            <p
              key={`sub-${currentSlide}`}
              className="font-heading text-2xl md:text-4xl lg:text-5xl text-gold-light italic mb-8 animate-fade-in-up animation-delay-200"
            >
              {slides[currentSlide].subtitle}
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center items-center mt-10 animate-fade-in-up animation-delay-400">
              <a
                href="#projects"
                className="bg-gradient-gold text-primary-foreground px-8 py-3.5 rounded-sm font-body text-sm uppercase tracking-wider hover:opacity-90 transition-all shadow-gold"
              >
                View Our Work
              </a>
              <a
                href="#about"
                className="border border-cream/40 text-cream px-8 py-3.5 rounded-sm font-body text-sm uppercase tracking-wider hover:bg-cream/10 transition-all"
              >
                Learn More
              </a>
            </div>
          </div>
        </div>
      </div>

      {/* Navigation Arrows */}
      <button
        onClick={prevSlide}
        className="absolute left-4 md:left-8 top-1/2 -translate-y-1/2 w-12 h-12 flex items-center justify-center border border-cream/30 text-cream hover:bg-cream/10 transition-all rounded-sm"
        aria-label="Previous slide"
      >
        <ChevronLeft size={24} />
      </button>
      <button
        onClick={nextSlide}
        className="absolute right-4 md:right-8 top-1/2 -translate-y-1/2 w-12 h-12 flex items-center justify-center border border-cream/30 text-cream hover:bg-cream/10 transition-all rounded-sm"
        aria-label="Next slide"
      >
        <ChevronRight size={24} />
      </button>

      {/* Slide Indicators */}
      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 flex gap-3">
        {slides.map((_, index) => (
          <button
            key={index}
            onClick={() => setCurrentSlide(index)}
            className={`w-3 h-3 rounded-full transition-all duration-300 ${
              index === currentSlide
                ? "bg-gold w-8"
                : "bg-cream/40 hover:bg-cream/60"
            }`}
            aria-label={`Go to slide ${index + 1}`}
          />
        ))}
      </div>
    </section>
  );
};

export default HeroSlider;
